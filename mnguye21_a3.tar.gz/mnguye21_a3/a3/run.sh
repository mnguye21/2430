javac GUI.java Portfolio.java MutualFund.java Stock.java Investment.java BuyWindow.java SellWindow.java UpdateWindow.java GetGainWindow.java SearchWindow.java
cd ..
java a3.GUI